/*
 * jukebox.h
 *
 *  Created on: Dec 27, 2024
 *      Author: sylou
 */

#ifndef CMSIS_JUKEBOX_JUKEBOX_H_
#define CMSIS_JUKEBOX_JUKEBOX_H_

#include "main.h"
 extern TIM_HandleTypeDef htim3;
// Macros
#define MUTE "-"

// Typedefs
typedef struct {
    const char *name;
    double frequency;
    uint16_t ARR;
} TypeDef_Note;

// Déclarations des fonctions
void jukebox_calculate_notes_ARR(TIM_HandleTypeDef *_htim, TypeDef_Note *_notes, size_t _notes_sz);
void buzzer_play_note(TIM_HandleTypeDef *_htim, TypeDef_Note *_note);
void buzzer_mute(TIM_HandleTypeDef *_htim);
void buzzer_play_note_by_name(TIM_HandleTypeDef *_htim, TypeDef_Note *_notes, size_t _notes_sz, const char *_name);
void buzzer_play_partition(TIM_HandleTypeDef *_htim, TypeDef_Note *_notes, size_t _notes_sz, const char **_partition, size_t _partition_sz);

// Variables externes
extern TypeDef_Note notes[];
extern size_t notes_sz;
extern const char *buzzer_partition[];
extern size_t buzzer_partition_sz;

#endif /* CMSIS_JUKEBOX_JUKEBOX_H_ */
