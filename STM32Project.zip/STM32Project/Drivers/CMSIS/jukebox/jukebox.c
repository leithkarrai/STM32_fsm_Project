/*
 * jukebox.c
 *
 *  Created on: Dec 27, 2024
 *      Author: sylou
 */

#include "jukebox.h"
#include <string.h>

// Variables globales
TypeDef_Note notes[] = {
    { "C5", 1046.50, 0 }, { "C#5", 1108.73, 0 }, { "D5", 1174.66, 0 },
    { "Eb5", 1244.51, 0 }, { "E5", 1318.51, 0 }, { "F5", 1396.91, 0 },
    { "F#5", 1479.98, 0 }, { "G5", 1567.98, 0 }, { "G#5", 1661.22, 0 },
    { "A5", 1760.00, 0 }, { "A#5", 1864.66, 0 }, { "B5", 1975.53, 0 }
};
size_t notes_sz = sizeof(notes) / sizeof(TypeDef_Note);

const char *buzzer_partition[] = {
    "G5", MUTE, "G5", MUTE, "G5", MUTE, "A5", MUTE, "B5", "B5", "B5",
    "B5", "A5", "A5", "A5", "A5", "G5", MUTE, "B5", MUTE, "A5", MUTE,
    "A5", MUTE, "G5", "G5", "G5", "G5", MUTE
};
size_t buzzer_partition_sz = sizeof(buzzer_partition) / sizeof(const char *);

// Implémentations des fonctions
void jukebox_calculate_notes_ARR(TIM_HandleTypeDef *_htim, TypeDef_Note *_notes, size_t _notes_sz) {
    // Obtenez la fréquence d'horloge du timer
    const uint32_t f_ck_psc = HAL_RCC_GetPCLK1Freq();
    const double f_ck_cnt = (double)(f_ck_psc / (_htim->Instance->PSC + 1));

    // Calculez les valeurs ARR pour chaque note
    for (size_t i = 0; i < _notes_sz; i++) {
        _notes[i].ARR = (uint16_t)((f_ck_cnt / _notes[i].frequency) - 1.0);
    }
}

void buzzer_play_note(TIM_HandleTypeDef *_htim, TypeDef_Note *_note) {
    const uint32_t f_ck_psc = HAL_RCC_GetPCLK1Freq();
    const uint32_t f_ck_cnt = f_ck_psc / (_htim->Instance->PSC + 1);
    const uint32_t f_ccrx = 5000; // 200µs
    const uint16_t ccr_value = f_ck_cnt / f_ccrx;

    if (HAL_TIM_PWM_Stop(_htim, TIM_CHANNEL_2) != HAL_OK) {
        Error_Handler();
    }

    __HAL_TIM_SET_AUTORELOAD(_htim, _note->ARR);
    __HAL_TIM_SET_COMPARE(_htim, TIM_CHANNEL_2, ccr_value);

    if (HAL_TIM_PWM_Start(_htim, TIM_CHANNEL_2) != HAL_OK) {
        Error_Handler();
    }
}

void buzzer_mute(TIM_HandleTypeDef *_htim) {
    if (HAL_TIM_PWM_Stop(_htim, TIM_CHANNEL_2) != HAL_OK) {
        Error_Handler();
    }
}

void buzzer_play_note_by_name(TIM_HandleTypeDef *_htim, TypeDef_Note *_notes, size_t _notes_sz, const char *_name) {
    if (strcmp(MUTE, _name) == 0) {
        buzzer_mute(_htim);
        return;
    }

    for (int i = 0; i < _notes_sz; i++) {
        if (strcmp(_notes[i].name, _name) == 0) {
            buzzer_play_note(_htim, &_notes[i]);
        }
    }
}

void buzzer_play_partition(TIM_HandleTypeDef *_htim, TypeDef_Note *_notes, size_t _notes_sz, const char **_partition, size_t _partition_sz) {
    static int note_index = 0;

    buzzer_play_note_by_name(_htim, _notes, _notes_sz, _partition[note_index]);
    note_index = (note_index + 1) % _partition_sz;

}

