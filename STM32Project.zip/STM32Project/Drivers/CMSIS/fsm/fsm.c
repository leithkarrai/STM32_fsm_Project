/*
 * fsm.c
 *
 *  Created on: Dec 2, 2024
 *      Author: Leïth
 */

#include "fsm.h"
#include "max7219.h"
#include "jukebox.h"
#include "main.h" // Include main header to access Chaser_State

#define next 1
#define prev 2
int test=0; //variable test pour la machine à état.
int BTNFlag=0; //flag pour changer l'état.


int DisplayFlag=0; //flag pour l'affichage sur l'afficheur 7 segments.
int speed=0; //contrôle de la vitesse d'affichage du jukebox et de l'afficheur.
uint32_t fsm_t_ref = 0;
uint32_t tim7_irq_cnt = 0;


State_Enum actual_state = START_STATE;

extern void Chaser_State(void); // Declare Chaser_State from main.c
extern void Buzzer_State(void); // Declare Buzzer_State from main.c
extern void Buzzer_Off(void); // Declare Buzzer_Off function from main.c
// FSM inputs

//ExecutionState_Enum execution_state = STATE_NOT_EXECUTED;

// Function pointer array storing states callbacks
// /!\ STORED IN THE SAME ORDER AS UserInput_Enum
void (*fsm_callbacks[])(void) = {
	start_state_callback,
	chaser_state_callback,
	buzzer_state_callback,
	jukebox_state_callback,
	display_state_callback,
};

void start_state_callback(void) {

	__NOP();
}

void chaser_state_callback(void) {
	// Call Chaser_State defined in main.c
	Chaser_State();
	__NOP();
}

void buzzer_state_callback(void){
	Buzzer_State(); // Activate the buzzer with the current pitch
	__NOP();
}
void jukebox_state_callback(void){
	test=3;


		if (tim7_irq_cnt > 0) {
									tim7_irq_cnt--;
									buzzer_play_partition(&htim3, notes, notes_sz, buzzer_partition, buzzer_partition_sz);
								}

		  //redéfinition de la vitesse en fonction des niveaux que l'on a choisi.
			  if(speed == 1){
				  TIM7->ARR=125;
			  }
			  if(speed == 2){
				  TIM7->ARR=100;
			  }
			  if(speed == 3){
				  TIM7->ARR=75;
			  }
			  if(speed == 4){
				  TIM7->ARR=50;
			  }
			  if(speed == 5){
				  TIM7->ARR=25;
			  }

		__NOP();
}
void display_state_callback(void){
	//max7219_Clean();
	test=4; //pour tester le bon fonctionnement de la callback.
	  if(DisplayFlag == 1){
	   max7219_PrintFtos(DIGIT_8, -3.14, 2);
	   max7219_PrintDigit(DIGIT_4, LETTER_H, false);
	   max7219_PrintDigit(DIGIT_3, LETTER_E, false);
	   max7219_PrintDigit(DIGIT_2, LETTER_L, false);
	   max7219_PrintDigit(DIGIT_1, LETTER_P, false);
	  }

	  else{
	   max7219_PrintNtos(DIGIT_8, 765, 4);
	   max7219_PrintItos(DIGIT_3, 321);
	  }
	  	  //redéfinition de la vitesse en fonction des niveaux que l'on a choisi.
	  if(speed ==1){
		  TIM6->ARR=1000;
	  }
	  if(speed == 2){
		  TIM6->ARR=750;
	  }
	  if(speed == 3){
		  TIM6->ARR=500;
	  }
	  if(speed == 4){
		  TIM6->ARR=250;
	  }
	  if(speed == 5){
		  TIM6->ARR=100;
	  }


	__NOP();
}

/**
 * @brief Initializes FSM
 * @param void
 * @return void
 */
void fsm_init(void) {
	// Reset actual state
	actual_state = START_STATE;

	fsm_t_ref = HAL_GetTick();
	//execution_state = STATE_NOT_EXECUTED;
}

/**
 * @brief Sets new state
 * @param _new_state New state to be set
 * @return void
 */
void fsm_set_new_state(State_Enum _new_state) {
    // If leaving BUZZER_STATE, turn off the buzzer
    if (actual_state == BUZZER_STATE && _new_state != BUZZER_STATE)
    {
        Buzzer_Off();
    }

    // Update the actual state
    actual_state = _new_state;
}

/**
 * @brief Executes a frame of the finite state machine and take care of transitions if needed
 * @param void
 * @return void
 */
void fsm_execute(void) {
	// 1 - State execution
	fsm_callbacks[actual_state]();


	// 2 - Check for transitions
	switch (actual_state) {
	case START_STATE:
		fsm_set_new_state(CHASER_STATE);

		break;
	case CHASER_STATE:
		if (BTNFlag == next) {
			BTNFlag-=next;
			fsm_set_new_state(BUZZER_STATE);
		}
		if (BTNFlag == prev){
			BTNFlag-=prev;
			fsm_set_new_state(DISPLAY_STATE);
		}
		break;
	case BUZZER_STATE:
		if (BTNFlag == next) {
			BTNFlag-=next;
			fsm_set_new_state(JUKEBOX_STATE);
		}
		if (BTNFlag == prev){
			BTNFlag-=prev;
			fsm_set_new_state(CHASER_STATE);
		}
		break;
	case JUKEBOX_STATE:
		if (BTNFlag == next) {
			BTNFlag-=next;
			fsm_set_new_state(DISPLAY_STATE);
		}
		if (BTNFlag == prev){
			BTNFlag-=prev;
			fsm_set_new_state(BUZZER_STATE);
		}
		break;

	case DISPLAY_STATE:
		if (BTNFlag == next) {
			BTNFlag-=next;
			fsm_set_new_state(CHASER_STATE);
		}
		if (BTNFlag == prev){
			BTNFlag-=prev;
			fsm_set_new_state(JUKEBOX_STATE);
		}
		break;
	}
}

